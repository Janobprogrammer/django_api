from django.contrib import admin
from .models import FriendList


admin.site.register(FriendList)
