from django.contrib import admin
from .models import FlashCard


admin.site.register(FlashCard)
