from django.contrib import admin
from .models import SubscriptionHistory


admin.site.register(SubscriptionHistory)
