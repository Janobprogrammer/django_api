from django.contrib import admin
from .models import UserAchievement


admin.site.register(UserAchievement)
