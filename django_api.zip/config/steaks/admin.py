from django.contrib import admin
from .models import Steak


admin.site.register(Steak)
