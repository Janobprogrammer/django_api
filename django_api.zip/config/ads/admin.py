from django.contrib import admin
from .models import InterAds


admin.site.register(InterAds)
