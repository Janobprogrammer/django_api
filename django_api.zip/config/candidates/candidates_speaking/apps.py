from django.apps import AppConfig


class SpeakingConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'candidates.candidates_speaking'
